#include <stdio.h>
int main() {
	int anchoP, altoP, cxIzq, cyIzq, cxDerecha, cyDerecha;
	float px, py, pAnchoElem, pAltoElem;
	scanf_s("%i", &anchoP);
	scanf_s("%i", &altoP);
	scanf_s("%f", &px);
	scanf_s("%f", &py);
	scanf_s("%f", &pAnchoElem);
	scanf_s("%f", &pAltoElem);
	cxIzq = anchoP * px;
	cyIzq = altoP * py;
	cxDerecha = (anchoP * pAnchoElem) + cxIzq;
	cyDerecha = (altoP * pAltoElem) + cyIzq;
	printf("%i %i %5.2f %5.2f %5.2f %5.2f %i %i %i %i", anchoP, altoP, px, py, pAnchoElem, pAltoElem, cxIzq, cyIzq, cxDerecha, cyDerecha);
	return 0;
}